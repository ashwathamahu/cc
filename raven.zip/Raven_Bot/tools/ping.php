<?php

$ping = $bot->taken($msg->date);

$msg = "[🏓] <b>Pong</b> ↯ <code>$ping</code>";